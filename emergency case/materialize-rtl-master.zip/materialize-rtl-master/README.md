![alt tag](https://raw.github.com/dogfalo/materialize/master/images/materialize.gif)
===========

Materialize, a CSS Framework based on material design

### Current Version : v0.97.0 (rtl)

Original structure is in [old branch](https://github.com/MahdiMajidzadeh/materialize-rtl/tree/old)

## Sass Requirements:
- Ruby Sass 3.3+, LibSass 0.6+

## Supported Browsers:
- Chrome 35+, Firefox 31+, Safari 7+, IE 10+

## Contributors

Materialize CSS framework originally developed by [Dogfalo](https://github.com/Dogfalo/materialize) and rtl version by [Mahdi Majidzadeh](https://github.com/MahdiMajidzadeh)
